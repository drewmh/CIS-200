﻿// CIS 200
// Program 4
// Fall 2022
// Drew Harris 5235190

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prog1
{
    class DescendingByDestZipComparer : Comparer<Parcel>
    {
        public override int Compare(Parcel p1, Parcel p2)
        {
            int zip1; // p1 destination zip
            int zip2; // p2 destination zip

            if (p1 == null && p2 == null)
                return 0;

            if (p1 == null)
                return -1;

            if (p2 == null)
                return 1;

            zip1 = p1.DestinationAddress.Zip;
            zip2 = p2.DestinationAddress.Zip;

            return (-1) * zip1.CompareTo(zip2); // -1 reverses the order, creating descending
        }
    }
}
