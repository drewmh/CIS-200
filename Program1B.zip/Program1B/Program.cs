﻿// Program 1B
// CIS 200-75
// Fall 2022
// Due: 10/12/2022
// By: 5235190

// File: Program.cs
// Simple test program for initial Parcel classes

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Program1A
{
    class Program
    {
        // Precondition:  None
        // Postcondition: Small list of Parcels is created and displayed
        static void Main(string[] args)
        {

            bool VERBOSE = false;

            Address a1 = new Address("  John Smith  ", "   123 Any St.   ", "  Apt. 45 ",
                "  Louisville   ", "  KY   ", 40202); // Test Address 1
            Address a2 = new Address("Jane Doe", "987 Main St.",
                "Beverly Hills", "CA", 90210); // Test Address 2
            Address a3 = new Address("James Kirk", "654 Roddenberry Way", "Suite 321",
                "El Paso", "TX", 79901); // Test Address 3
            Address a4 = new Address("John Crichton", "678 Pau Place", "Apt. 7",
                "Portland", "ME", 04101); // Test Address 4
            Address a5 = new Address("John Doe", "11 Market St.", "Jeffersonville", "IN", 47310);
            Address a6 = new Address("Jane Smith", "55 Hollywood Blvd.", "Apt. 9", "Los Angeles", "CA", 90212);
            Address a7 = new Address("Cpt. Robert Crunch", "21 Cereal Rd.", "Room 987", "Bethesda", "MD", 20810);
            Address a8 = new Address("Vlad Dracula", "6543 Vampire Way", "apt 1", "Bloodsucker City", "TN", 37210);

            Letter letter1 = new Letter(a1, a2, 3.95M);
            Letter letter2 = new Letter(a3, a4, 4.25M);
            GroundPackage gp1 = new GroundPackage(a3, a4, 14, 10, 5, 12.5);
            GroundPackage gp2 = new GroundPackage(a7, a8, 8.5, 9.5, 6.5, 2.5);
            NextDayAirPackage ndap1 = new NextDayAirPackage(a1, a3, 25, 15, 10, 30, 7.50M);
            NextDayAirPackage ndap2 = new NextDayAirPackage(a3, a5, 9.5, 6.0, 5.5, 5.25, 5.25M);
            NextDayAirPackage ndap3 = new NextDayAirPackage(a2, a7, 10.5, 6.5, 9.5, 15.5, 5.00M);
            TwoDayAirPackage tdap1 = new TwoDayAirPackage(a4, a1, 46.5, 39.5, 15.5, 80.6, TwoDayAirPackage.Delivery.Saver);
            TwoDayAirPackage tdap2 = new TwoDayAirPackage(a8, a1, 15.0, 9.5, 6.5, 75.5, TwoDayAirPackage.Delivery.Early);
            TwoDayAirPackage tdap3 = new TwoDayAirPackage(a6, a4, 12.0, 12.0, 6.0, 5.5, TwoDayAirPackage.Delivery.Saver);

            List<Parcel> parcels; // list of test parcels

            parcels = new List<Parcel>();

            parcels.Add(letter1);
            parcels.Add(letter2);
            parcels.Add(gp1);
            parcels.Add(gp2);
            parcels.Add(ndap1);
            parcels.Add(ndap2);
            parcels.Add(ndap3);
            parcels.Add(tdap1);
            parcels.Add(tdap2);
            parcels.Add(tdap3);

            // Display data
            WriteLine("Original List:");
            WriteLine("Program 1A\n");

            foreach (Parcel p in parcels)
            {
                WriteLine(p);
                WriteLine("--------------------");
            }
            Pause();

            // Parcels by Destination Zip (desc)
            var parcelsByDestZip =
                from p in parcels
                orderby p.DestinationAddress.Zip descending
                select p;

            WriteLine("Parcels by Destination Zip (desc):");
            WriteLine("=======================");

            foreach (Parcel p in parcelsByDestZip)
            {
                if (VERBOSE)
                {
                    WriteLine(p);
                    WriteLine("======================");
                }
                else
                    WriteLine($"{p.DestinationAddress.Zip:D5}");
            }
            Pause();

            // Parcels by cost
            var parcelsByCost =
                from p in parcels
                orderby p.CalcCost()
                select p;

            WriteLine("Parcels by cost:");
            WriteLine("========================");
            foreach (Parcel p in parcelsByCost)
            {
                if (VERBOSE)
                {
                    WriteLine(p);
                    WriteLine("======================");
                }
                else
                    WriteLine($"{p.CalcCost(),8:C}");
            }
            Pause();

            var parcelsByTypeCost =
                from p in parcels
                orderby p.GetType().ToString(), p.CalcCost() descending
                select p;

            WriteLine("Parcels by Type and Cost (desc):");
            WriteLine("========================");
            foreach (Parcel p in parcelsByTypeCost)
            {
                if (VERBOSE)
                {
                    WriteLine(p);
                    WriteLine("======================");
                }
                else
                    WriteLine($"{p.GetType().ToString(),-17} {p.CalcCost(),8:C}");
            }
            Pause();

            // Heavy AirPackages by Weight
            var heavyAirPackagesByWeight =
                from p in parcels
                let ap = p as AirPackage // downcast if airpackage, null otherwise
                where (ap != null) && ap.IsHeavy() // safe because of short-circuit
                orderby ap.Weight descending
                select ap;

            WriteLine("Heavy airPackages by Weight (desc):");
            WriteLine("=============================");
            foreach (AirPackage ap in heavyAirPackagesByWeight)
            {
                if (VERBOSE)
                {
                    WriteLine(ap);
                    WriteLine("======================");
                }
                else
                    WriteLine("{0,-17} {1,4:F1}", ap.GetType().ToString(), ap.Weight);
            }
        }

        public static void Pause()
        {
            WriteLine("Press Enter to Continue...");
            ReadLine();
            Clear();
        }
    }
}
