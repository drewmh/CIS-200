﻿// Program 1A
// CIS 200
// Fall 2022
// Due: 9/26/2022
// Drew Harris, 5235190

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public abstract class AirPackage : Package
{
    public const double HEAVY_THRESHOLD = 75; // min weight of hvy package
    public const double LARGE_THRESHOLD = 100; // min dim. of large package

    public AirPackage(Address originAddress, Address destAddress, double pLength, double pWidth, double pHeight, double pWeight)
        : base(originAddress, destAddress, pLength, pWidth, pHeight, pWeight)
    {
        // All work done in base class constructor
    }

    // pre none
    // post returns true if air package considered heavy
    public bool IsHeavy()
    {
        return (Weight >= HEAVY_THRESHOLD);
    }

    // pre none
    // post returns true if air package considered large
    public bool IsLarge()
    {
        return (TotalDimension >= LARGE_THRESHOLD);
    }

    // pre none
    // post string with air package data is returned
    public override String ToString()
    {
        string NL = Environment.NewLine;

        return $"Air{base.ToString()}{NL}Heavy: {IsHeavy()}{NL}Large: {IsLarge()}";
    }
}