﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program0
{
    internal abstract class Parcel
    {
        private Address _originAddress;
        private Address _destinationAddress;

        public Parcel(Address originAddress, Address destinationAddress)
        {
            OriginAddress = originAddress;
            DestinationAddress = destinationAddress;
        }

        public Address OriginAddress
        {
            // Precondition: None
            // Postcondition: The parcel's origin address has been returned.
            get { return _originAddress; }

            // Precondition: value must not be null
            // Postcondition: The parcel's origin address has been set to the specified value.
            set
            {
                if (value == null)
                {
                    throw new ArgumentOutOfRangeException($"{nameof(OriginAddress)}", value, $"{nameof(OriginAddress)} must not be null.");
                }

                else
                    _originAddress = value;
            }
        }

        public Address DestinationAddress
        {
            // Precondition: None
            // Postcondition: The parcel's destination address has been returned.
            get { return _destinationAddress; }

            // Precondition: value must not be null
            // Postcondition: The parcel's destination address has been set to the specified value.
            set
            {
                if (value == null)
                {
                    throw new ArgumentOutOfRangeException($"{nameof(DestinationAddress)}", value, $"{nameof(DestinationAddress)} must not be null.");
                }

                else
                    _destinationAddress = value;
            }
        }

        public abstract decimal CalcCost();

        public override string ToString()
        {
            string NL = Environment.NewLine;

            return $"Origin Address:{NL}{OriginAddress}{NL}{NL}Destination Address:{NL}{DestinationAddress}{NL}{NL}Cost: {CalcCost():C}";
        }
    }
}
