﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program0
{
    class Letter : Parcel
    {
        private decimal _fixedCost;

        public Letter(Address originAddress, Address destinationAddress, decimal cost) : base(originAddress, destinationAddress)
        {
            FixedCost = cost;
        }

        public decimal FixedCost
        {
            get { return _fixedCost; }

            // Precondition: value >= 0
            // Postcondition: The letter's fixed cost has been set to the specified value
            set
            {
                if (value >= 0)
                {
                    _fixedCost = value;
                }
                else
                {
                    throw new ArgumentOutOfRangeException($"{nameof(FixedCost)}", value, $"{nameof(FixedCost)} must not be >=0.");
                }
            }
        }

        public override decimal CalcCost()
        {
            return FixedCost;
        }

        public override string ToString()
        {
            string NL = Environment.NewLine;

            return $"Letter{NL}{base.ToString()}";
        }
    }
}
